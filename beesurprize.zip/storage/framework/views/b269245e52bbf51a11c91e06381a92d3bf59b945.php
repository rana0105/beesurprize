<!-- Bootstrap core JavaScript -->
  <script src="<?php echo e(asset('frontend/vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo e(asset('frontend/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="<?php echo e(asset('frontend/js/scrolling-nav.js')); ?>"></script>
  <?php /**PATH /var/www/html/beesurprize/resources/views/frontend/partial/script.blade.php ENDPATH**/ ?>