<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="col-md-6">
            <h6 class="m-0 font-weight-bold text-success">
                Winner List
            </h6>
        </div>
    </div>
    <div class="card-body">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>
                Whoops!
            </strong>
            There were some problems with your input.
            <br>
                <br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </br>
            </br>
        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table cellspacing="0" class="table table-bordered custom-btn" id="dataTable" width="100%">
                <thead>
                    <tr>
                        <th>
                            #
                        </th>
                        <th>Image</th>
                        <th>Winner Name</th>
                        <th>
                            Prize
                        </th>
                        
                        <th>
                            Contest No
                        </th>
                        <th>
                            Competition Title
                        </th>
                        <th>
                            Draw Date
                        </th>
                        <th>
                            Winner Number
                        </th>
                        
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>
                            #
                        </th>
                        <th>Image</th>
                        <th>Winner Name</th>
                        <th>
                            Prize
                        </th>
                        
                        <th>
                            Contest No
                        </th>
                        <th>
                            Competition Title
                        </th>
                        <th>
                            Draw Date
                        </th>
                        <th>
                            Winner Number
                        </th>
                        
                    </tr>
                </tfoot>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td><img src="<?php echo e(asset('/backend/img/admin.png')); ?>" alt=""></td>
                        <td>Sumrat</td>
                        <td>Car</td>
                        
                        <td>B2T</td>
                        <td>The Breeze</td>
                        <td>12-Aug-2020</td>
                        <td>21354233</td>
                        
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
      $('#dataTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/beesurprize/resources/views/backend/users/winnerList.blade.php ENDPATH**/ ?>