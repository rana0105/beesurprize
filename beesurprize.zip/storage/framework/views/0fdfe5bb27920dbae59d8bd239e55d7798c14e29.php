 <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('backend/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('frontend/css/scrolling-nav.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"><?php /**PATH /var/www/html/beesurprize/resources/views/frontend/partial/style.blade.php ENDPATH**/ ?>