<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="row">
            <div class="col-md-6">
                <h6 class="m-0 font-weight-bold text-success">
                    Create Testmonial
                </h6>
            </div>
            <div class="col-md-6" style="text-align: right">
                <h6 class="m-0 font-weight-bold text-success">
                    <a href="<?php echo e(route('customer-testmonial')); ?>">
                        <i aria-hidden="true" class="fas fa-sign-out-alt fa-sm fa-fw mr-2">
                        </i>
                        Back
                    </a>
                </h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>
                Whoops!
            </strong>
            There were some problems with your input.
            <br>
                <br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </br>
            </br>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('blogs.store')); ?>" method="POST" enctype="multipart/form-data" file="true">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="title">
                    Title
                </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="title" name="title">
                    </input>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="inputPassword">
                    Comment
                </label>
                <div class="col-sm-10">
                    <textarea name="detail" id="detail" cols="30" rows="5" class="form-control"></textarea>
                    </input>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label" for="title">
                    Customer
                </label>
                <div class="col-sm-10">
                    <select class="form-control" id="makers" name="makers">
                        <option value="">Sumrat</option>
                        <option value="">Mahin</option>
                        <option value="">Boby</option>
                    </select>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button class="btn btn-success" type="submit">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
   // tinymce.init({
   //   selector: 'textarea#detail'
   // });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/beesurprize/resources/views/backend/testmonial/testmonialCreate.blade.php ENDPATH**/ ?>