<!-- Bootstrap core JavaScript -->
  <script src="{{ asset('frontend/vendor/jquery/jquery.min.js') }}"></script>
  <script src="{{ asset('frontend/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

  <!-- Plugin JavaScript -->
  <script src="{{ asset('frontend/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="{{ asset('frontend/js/scrolling-nav.js') }}"></script>
  {{-- <script src="{{ asset('js/app.js') }}" defer></script> --}}