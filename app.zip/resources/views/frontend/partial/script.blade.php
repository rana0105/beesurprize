<!-- Bootstrap core JavaScript -->
  <script src="{{ asset('frontend/js/jquery-3.4.1.min.js') }}"></script>
  <script src="{{ asset('frontend/js/popper.js') }}"></script>
  <script src="{{ asset('frontend/js/bootstrap.js') }}"></script>
  <script src="{{ asset('frontend/js/select2.min.js') }}"></script>
  <script src="{{ asset('frontend/js/monthpicker.min.js') }}"></script>
  <script src="{{ asset('https://cdn.jsdelivr.net/sharer.js/latest/sharer.min.js') }}"></script>
  <script src="{{ asset('https://cdn.datatables.net/v/dt/dt-1.10.15/datatables.min.js') }}"></script>
  <script src="{{ asset('https://cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/1.6.2/jquery.mockjax.min.js') }}"></script>
  <script src="{{ asset('https://gyrocode.github.io/jquery-datatables-pageLoadMore/1.0.0/js/dataTables.pageLoadMore.min.js') }}"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="{{ asset('frontend/js/script.js') }}"></script>
  {{-- <script src="{{ asset('js/app.js') }}" defer></script> --}}