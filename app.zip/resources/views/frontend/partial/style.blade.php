 <!-- Custom fonts for this template-->
  <link href="{{ asset('https://use.fontawesome.com/releases/v5.0.13/css/all.css') }}" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">

<!-- Bootstrap core CSS -->
  <link href="{{ asset('frontend/css/bootstrap.css') }}" rel="stylesheet">
  <link href="{{ asset('frontend/css/select2.min.css') }}" rel="stylesheet">
  <link href="{{ asset('frontend/css/monthpicker.css') }}" rel="stylesheet">
  <link href="{{ asset('frontend/css/style.css') }}" rel="stylesheet">

  <!-- Custom styles for this template -->
  {{-- <link href="{{ asset('css/app.css') }}" rel="stylesheet"> --}}