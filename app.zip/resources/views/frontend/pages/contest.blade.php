@extends('frontend.layouts.main')
@section('content')

	<div class="container">
		<div class="contest-heading">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 col-sm-12">
					<div class="contest-title">
						<h1>current contest</h1>
						<p>See all of our current contest</p>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-2 col-md-4">
				<div class="form-group filering-element">
	                <select class="form-control">
	                    <option>Sort by</option>
	                    <option>Newest</option>
	                    <option>Oldest</option>
	                    <option>Price high to low</option>
	                    <option>Price low to high</option>
	                </select>
	            </div>
			</div>
			<div class="col-lg-2 col-md-4">
				<div class="form-group filering-element">
	                <select class="form-control">
	                    <option>Prize</option>
	                    <option>Car</option>
	                    <option>Bike</option>
	                    <option>Desktop</option>
	                    <option>Money</option>
	                </select>
	            </div>
			</div>
			<div class="col-lg-2 col-md-4">
				<div class="form-group filering-element">
	                <select class="prize-brand form-control">
	                    <option>All makers</option>
	                    <option>BMW</option>
	                    <option>Ferrari</option>
	                    <option>Honda</option>
	                    <option>Yamaha</option>
	                    <option>Suzuki</option>
	                </select>
	            </div>
			</div>
			<div class="col-lg-2 col-md-4">
				<div class="form-group">
					<div class="rangewrapper">
					  	<div class="sliderfill">
					  		<input class="customrange" type="range" min="0" max="100" value="30">
					  	</div>
					  	<div class="sliderthumb"></div>
					  	<div class="slidervalue">50</div>
					</div>
				</div>
			</div>
            <div class="col-lg-2 col-md-4">
                <div class="form-group">
                    <div class="wish-filtering">
                        <button><i class="fas fa-heart"></i></button>
                        <button><i class="fas fa-history"></i></button>
                    </div>
                </div>
            </div>
			<div class="col-lg-2 col-md-4">
				<div class="form-group filering-element">
					<input type="search" class="form-control" placeholder="Search here">
				</div>
			</div>
			<div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="{{ route('live.contest.detail') }}">
                        <div class="prize-img">
                            <img src="img/cars.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>B2T</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="{{ route('live.contest.detail') }}" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/motorcycle.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>B2T</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/smartphone.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>X9U</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/motorcycle.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>B2T</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/smartphone.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>X9U</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/motorcycle.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>B2T</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="current-item">
                    <a href="contest-detail.php">
                        <div class="prize-img">
                            <img src="img/smartphone.png">
                        </div>
                    </a>
                    <div class="fav-icon">
                        <a href="#"><i class="far fa-heart"></i></a>
                    </div>
                    <div class="contest-no">
                        Contest No:<br><span>X9U</span>
                    </div>
                    <div class="ticket-detail">
                        <a href="contest-detail.php" class="prize-name">The Breeze  Zodiac IX</a>
                        <p class="ticket-price">$3.95</p>
                        <hr>
                        <div class="ticket-info">
                            <i class="far fa-clock"></i> 5d  <span class="bar">|</span>
                            <span class="float-right"><i class="fas fa-ticket-alt"></i> 9805 <b>Remaining</b></span>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>

@endsection